import Web3 from 'web3';
const web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
let greetingABI = [{"constant":false,"inputs":[{"internalType":"string","name":"_greeting","type":"string"}],"name":"setGreet","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"getGreet","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"}];
let greeterAddress = '0x1185f9ec37681be769d639de92b882de778f702d';
const greeterContract = web3.eth.contract(greetingABI).at(greeterAddress);

export{greeterContract}