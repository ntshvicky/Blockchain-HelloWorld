import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import {greeterContract} from './EthereumSetup';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      greeting: ""
    }
  }

  componentDidMount() {
    var data = greeterContract.getGreet()
    this.setState({
      greeting: data
    })
  }

  render() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h2>Welcome to Greeting Blockchain</h2>
      </header>
      <h2> "{this.state.greeting}" </h2>
    </div>
  );
  }
}

export default App;
